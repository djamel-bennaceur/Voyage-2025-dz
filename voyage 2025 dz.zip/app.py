
from flask import Flask, request, render_template, send_file
from utils.generate_offer import generate_offer
from utils.send_email import send_email
import os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate():
    data = request.form.to_dict()
    offer_path = generate_offer(data)
    send_email(data['email'], offer_path)
    return send_file(offer_path, as_attachment=True)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
