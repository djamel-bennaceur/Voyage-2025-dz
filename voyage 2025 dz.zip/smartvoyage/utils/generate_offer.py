
from fpdf import FPDF
import os

def generate_offer(data):
    filename = f"offer_{data['destination']}.pdf"
    filepath = os.path.join("smartvoyage", filename)
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt=f"Your SmartVoyage Offer", ln=1, align='C')
    pdf.cell(200, 10, txt=f"Destination: {data['destination']}", ln=2)
    pdf.cell(200, 10, txt=f"Duration: {data['duration']}", ln=3)
    pdf.output(filepath)
    return filepath
