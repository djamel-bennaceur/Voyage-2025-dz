
import smtplib
from email.message import EmailMessage

def send_email(recipient, filepath):
    msg = EmailMessage()
    msg['Subject'] = 'Your SmartVoyage Offer'
    msg['From'] = 'you@example.com'
    msg['To'] = recipient
    msg.set_content('Find your travel offer attached.')

    with open(filepath, 'rb') as f:
        file_data = f.read()
        file_name = os.path.basename(filepath)

    msg.add_attachment(file_data, maintype='application', subtype='pdf', filename=file_name)

    with smtplib.SMTP('smtp.example.com', 587) as smtp:
        smtp.starttls()
        smtp.login('you@example.com', 'yourpassword')
        smtp.send_message(msg)
